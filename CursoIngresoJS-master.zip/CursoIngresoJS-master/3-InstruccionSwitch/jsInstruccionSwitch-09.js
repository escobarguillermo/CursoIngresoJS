function mostrar()
{
	var estacionIngresada =txtIdEstacion.value;
	alert(estacionIngresada);

}//FIN DE LA FUNCIÓN