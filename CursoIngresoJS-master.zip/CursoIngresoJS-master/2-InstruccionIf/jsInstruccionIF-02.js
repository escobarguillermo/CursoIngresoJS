function mostrar()
{
	//tomo la edad  
	alert("ok");
	

}//FIN DE LA FUNCIÓN